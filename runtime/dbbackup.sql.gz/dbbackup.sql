-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: host_34069
-- ------------------------------------------------------
-- Server version	5.5.41-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `module` varchar(100) DEFAULT '',
  `object_model` varchar(100) DEFAULT '',
  `object_id` varchar(100) DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
INSERT INTO `activity` VALUES (1,'ActivitySpaceCreated','','','','2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1),(2,'PostCreated','post','Post','1','2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `space_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) NOT NULL,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `visibility` tinyint(4) DEFAULT NULL,
  `sticked` tinyint(4) DEFAULT NULL,
  `archived` tinytext,
  `space_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_object_model` (`object_model`,`object_id`),
  UNIQUE KEY `index_guid` (`guid`),
  KEY `index_space_id` (`space_id`),
  KEY `index_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,'503ab983-83c4-497b-ab97-de64f08ea7a9','Activity',1,1,0,'0',1,1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1),(2,'1bc618d3-aaca-4e62-9f2f-dc51ca292cfd','Post',1,1,0,'0',1,1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1),(3,'9e48d576-ce25-4b16-8b57-fcb66ff18e9a','Activity',2,1,0,'0',1,1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) DEFAULT NULL,
  `object_model` varchar(100) DEFAULT '',
  `object_id` varchar(100) DEFAULT '',
  `file_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `mime_type` varchar(150) DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_object` (`object_model`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `space_id` int(10) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_dn` varchar(255) DEFAULT NULL,
  `can_create_public_spaces` int(1) DEFAULT '1',
  `can_create_private_spaces` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` VALUES (1,NULL,'Users','Example Group by Installer','2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,1,1);
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_admin`
--

DROP TABLE IF EXISTS `group_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin` (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_admin`
--

LOCK TABLES `group_admin` WRITE;
/*!40000 ALTER TABLE `group_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `like`
--

DROP TABLE IF EXISTS `like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_user_id` int(11) DEFAULT NULL,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_object` (`object_model`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `like`
--

LOCK TABLES `like` WRITE;
/*!40000 ALTER TABLE `like` DISABLE KEYS */;
/*!40000 ALTER TABLE `like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logging`
--

DROP TABLE IF EXISTS `logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logging` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(128) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `logtime` int(11) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logging`
--

LOCK TABLES `logging` WRITE;
/*!40000 ALTER TABLE `logging` DISABLE KEYS */;
INSERT INTO `logging` VALUES (1,'error','exception.CHttpException.404',1425912647,'exception \'CHttpException\' with message \'Unable to resolve the request \"favicon.ico\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'favicon.ico\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/favicon.ico\n---'),(2,'error','exception.CHttpException.404',1425912652,'exception \'CHttpException\' with message \'Unable to resolve the request \"favicon.ico\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'favicon.ico\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/favicon.ico\n---'),(3,'error','exception.CHttpException.404',1425912655,'exception \'CHttpException\' with message \'Unable to resolve the request \"favicon.ico\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'favicon.ico\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/favicon.ico\n---'),(4,'error','exception.CHttpException.404',1425912657,'exception \'CHttpException\' with message \'Unable to resolve the request \"favicon.ico\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'favicon.ico\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/favicon.ico\n---'),(5,'error','exception.CHttpException.404',1425912677,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(6,'error','exception.CHttpException.404',1425912677,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(7,'error','exception.CHttpException.404',1425912680,'exception \'CHttpException\' with message \'Unable to resolve the request \"favicon.ico\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'favicon.ico\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/favicon.ico\n---'),(8,'error','exception.CHttpException.404',1425912680,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(9,'error','exception.CHttpException.404',1425912680,'exception \'CHttpException\' with message \'Unable to resolve the request \"installer/index/go\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'installer/index...\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/installer/index/go\nHTTP_REFERER=http://qwertyuiop198.humhub.com/installer/index/go\n---'),(10,'error','exception.CHttpException.404',1425912681,'exception \'CHttpException\' with message \'Unable to resolve the request \"installer/config/index\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'installer/confi...\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/installer/config/index\nHTTP_REFERER=http://qwertyuiop198.humhub.com/installer/config/index\n---'),(11,'error','exception.CHttpException.404',1425912685,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(12,'error','exception.CHttpException.404',1425912693,'exception \'CHttpException\' with message \'Unable to resolve the request \"installer/config/basic\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'installer/confi...\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/installer/config/basic\nHTTP_REFERER=http://qwertyuiop198.humhub.com/installer/config/basic\n---'),(13,'error','exception.CHttpException.404',1425912712,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(14,'error','exception.CHttpException.404',1425912713,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(15,'error','exception.CHttpException.404',1425912714,'exception \'CHttpException\' with message \'Unable to resolve the request \"robots.txt\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'robots.txt\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/robots.txt\nHTTP_REFERER=http://qwertyuiop198.humhub.com/robots.txt\n---'),(16,'error','exception.CHttpException.404',1425912717,'exception \'CHttpException\' with message \'Unable to resolve the request \"installer/config/finished\".\' in /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php:286\nStack trace:\n#0 /srv/www/humhub/protected/vendors/yii/web/CWebApplication.php(141): CWebApplication->runController(\'installer/confi...\')\n#1 /srv/www/humhub/protected/vendors/yii/base/CApplication.php(180): CWebApplication->processRequest()\n#2 /srv/www/htdocs/qwertyuiop198/index.php(49): CApplication->run()\n#3 {main}\nREQUEST_URI=/installer/config/finished\nHTTP_REFERER=http://qwertyuiop198.humhub.com/installer/config/finished\n---');
/*!40000 ALTER TABLE `logging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  `module` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration`
--

LOCK TABLES `migration` WRITE;
/*!40000 ALTER TABLE `migration` DISABLE KEYS */;
INSERT INTO `migration` VALUES ('m000000_000000_base_activity',1425912640,'activity'),('m000000_000000_base_admin',1425912641,'admin'),('m000000_000000_base_comment',1425912640,'comment'),('m000000_000000_base_core',1425912640,'core'),('m000000_000000_base_file',1425912640,'file'),('m000000_000000_base_like',1425912640,'like'),('m000000_000000_base_notification',1425912640,'notification'),('m000000_000000_base_post',1425912640,'post'),('m000000_000000_base_space',1425912640,'space'),('m000000_000000_base_user',1425912639,'user'),('m000000_000000_base_wall',1425912640,'wall'),('m131023_164513_initial',1425912640,'user'),('m131023_165411_initial',1425912640,'space'),('m131023_165625_initial',1425912640,'wall'),('m131023_165755_initial',1425912640,'core'),('m131023_165835_initial',1425912640,'post'),('m131023_170033_initial',1425912640,'notification'),('m131023_170135_initial',1425912640,'like'),('m131023_170159_initial',1425912640,'file'),('m131023_170253_initial',1425912640,'comment'),('m131023_170339_initial',1425912640,'activity'),('m131203_110444_oembed',1425912640,'core'),('m131213_165552_user_optimize',1425912641,'user'),('m140226_111945_ldap',1425912641,'core'),('m140303_125031_password',1425912641,'user'),('m140304_142711_memberautoadd',1425912641,'space'),('m140321_000917_content',1425912641,'core'),('m140324_170617_membership',1425912641,'space'),('m140507_150421_create_settings_table',1425912641,'user'),('m140507_171527_create_settings_table',1425912641,'space'),('m140512_141414_i18n_profilefields',1425912641,'user'),('m140513_180317_createlogging',1425912641,'admin'),('m140701_000611_profile_genderfield',1425912641,'user'),('m140701_074404_protect_default_profilefields',1425912641,'user'),('m140702_143912_notify_notification_unify',1425912641,'wall'),('m140703_104527_profile_birthdayfield',1425912642,'user'),('m140704_080659_installationid',1425912642,'admin'),('m140705_065525_emailing_settings',1425912642,'user'),('m140706_135210_lastlogin',1425912642,'user'),('m140829_122906_delete',1425912642,'user'),('m140830_145504_following',1425912642,'core'),('m140901_080147_indizies',1425912642,'like'),('m140901_080432_indices',1425912642,'file'),('m140901_112246_addState',1425912642,'space'),('m140901_153403_addState',1425912642,'user'),('m140901_170329_group_create_space',1425912642,'user'),('m140902_091234_session_key_length',1425912642,'user'),('m140907_140822_zip_field_to_text',1425912643,'user'),('m140930_205511_fix_default',1425912643,'activity'),('m140930_205859_fix_default',1425912643,'like'),('m140930_210142_fix_default',1425912643,'file'),('m140930_210635_fix_default',1425912643,'user'),('m140930_212528_fix_default',1425912643,'notification'),('m141015_173305_follow_notifications',1425912643,'core'),('m141019_093319_mentioning',1425912643,'user'),('m141020_162639_fix_default',1425912643,'core'),('m141020_193920_rm_alsocreated',1425912643,'comment'),('m141020_193931_rm_alsoliked',1425912643,'like'),('m141021_162639_oembed_setting',1425912643,'core'),('m141022_094635_addDefaults',1425912643,'space'),('m141031_140056_cleanup_profiles',1425912643,'user');
/*!40000 ALTER TABLE `migration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_enabled`
--

DROP TABLE IF EXISTS `module_enabled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_enabled` (
  `module_id` varchar(100) NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_enabled`
--

LOCK TABLES `module_enabled` WRITE;
/*!40000 ALTER TABLE `module_enabled` DISABLE KEYS */;
/*!40000 ALTER TABLE `module_enabled` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `source_object_model` varchar(100) DEFAULT NULL,
  `source_object_id` int(11) DEFAULT NULL,
  `target_object_model` varchar(100) DEFAULT NULL,
  `target_object_id` int(11) DEFAULT NULL,
  `space_id` int(11) DEFAULT NULL,
  `emailed` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_2trash` text,
  `message` text,
  `url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,NULL,'Yay! I\'ve just installed HumHub :-)',NULL,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `birthday_hide_year` int(1) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `about` text,
  `phone_private` varchar(255) DEFAULT NULL,
  `phone_work` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `im_skype` varchar(255) DEFAULT NULL,
  `im_msn` varchar(255) DEFAULT NULL,
  `im_icq` int(11) DEFAULT NULL,
  `im_xmpp` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `url_facebook` varchar(255) DEFAULT NULL,
  `url_linkedin` varchar(255) DEFAULT NULL,
  `url_xing` varchar(255) DEFAULT NULL,
  `url_youtube` varchar(255) DEFAULT NULL,
  `url_vimeo` varchar(255) DEFAULT NULL,
  `url_flickr` varchar(255) DEFAULT NULL,
  `url_myspace` varchar(255) DEFAULT NULL,
  `url_googleplus` varchar(255) DEFAULT NULL,
  `url_twitter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'Zak','Farmer','System Administration',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_field`
--

DROP TABLE IF EXISTS `profile_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_field_category_id` int(11) NOT NULL,
  `module_id` varchar(255) DEFAULT NULL,
  `field_type_class` varchar(255) NOT NULL,
  `field_type_config` text,
  `internal_name` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `required` tinyint(4) DEFAULT NULL,
  `show_at_registration` tinyint(4) DEFAULT NULL,
  `editable` tinyint(4) NOT NULL DEFAULT '1',
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_attribute` varchar(255) DEFAULT NULL,
  `translation_category` varchar(255) DEFAULT NULL,
  `is_system` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_profile_field_category` (`profile_field_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_field`
--

LOCK TABLES `profile_field` WRITE;
/*!40000 ALTER TABLE `profile_field` DISABLE KEYS */;
INSERT INTO `profile_field` VALUES (1,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','firstname','Firstname',NULL,100,1,1,1,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,'givenName',NULL,1),(2,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','lastname','Lastname',NULL,200,1,1,1,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,'sn',NULL,1),(3,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','title','Title',NULL,300,NULL,0,1,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,'title',NULL,1),(4,1,NULL,'ProfileFieldTypeSelect','{\"options\":\"male=>Male\\nfemale=>Female\\ncustom=>Custom\"}','gender','Gender',NULL,300,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(5,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":150,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','street','Street',NULL,400,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(6,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":10,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','zip','Zip',NULL,500,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(7,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','city','City',NULL,600,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(8,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','country','Country',NULL,700,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(9,1,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','state','State',NULL,800,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(10,1,NULL,'ProfileFieldTypeBirthday','{\"showTimePicker\":false}','birthday','Birthday',NULL,900,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(11,1,NULL,'ProfileFieldTypeTextArea','[]','about','About',NULL,900,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(12,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','phone_private','Phone Private',NULL,100,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(13,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','phone_work','Phone Work',NULL,200,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(14,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','mobile','Mobile',NULL,300,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(15,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','fax','Fax',NULL,400,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(16,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','im_skype','Skype Nickname',NULL,500,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(17,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','im_msn','MSN',NULL,600,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(18,2,NULL,'ProfileFieldTypeNumber','{\"maxValue\":null,\"minValue\":null}','im_icq','ICQ Number',NULL,700,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(19,2,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"email\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','im_xmpp','XMPP Jabber Address',NULL,800,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(20,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url','Url',NULL,100,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(21,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_facebook','Facebook URL',NULL,200,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(22,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_linkedin','LinkedIn URL',NULL,300,NULL,0,1,1,'2015-03-09 15:50:50',NULL,'2015-03-09 15:50:50',NULL,NULL,NULL,1),(23,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_xing','Xing URL',NULL,400,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(24,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_youtube','Youtube URL',NULL,500,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(25,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_vimeo','Vimeo URL',NULL,600,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(26,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_flickr','Flickr URL',NULL,700,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(27,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_myspace','MySpace URL',NULL,800,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(28,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_googleplus','Google+ URL',NULL,900,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1),(29,3,NULL,'ProfileFieldTypeText','{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null}','url_twitter','Twitter URL',NULL,1000,NULL,0,1,1,'2015-03-09 15:50:51',NULL,'2015-03-09 15:50:51',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `profile_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_field_category`
--

DROP TABLE IF EXISTS `profile_field_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_field_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `module_id` int(11) DEFAULT NULL,
  `visibility` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `translation_category` varchar(255) DEFAULT NULL,
  `is_system` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_field_category`
--

LOCK TABLES `profile_field_category` WRITE;
/*!40000 ALTER TABLE `profile_field_category` DISABLE KEYS */;
INSERT INTO `profile_field_category` VALUES (1,'General','',100,NULL,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,NULL,1),(2,'Communication','',200,NULL,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,NULL,1),(3,'Social bookmarks','',300,NULL,1,'2015-03-09 15:50:49',NULL,'2015-03-09 15:50:49',NULL,NULL,1);
/*!40000 ALTER TABLE `profile_field_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `value_text` text,
  `module_id` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'oembedProviders',NULL,'{\"vimeo.com\":\"http:\\/\\/vimeo.com\\/api\\/oembed.json?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtube.com\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtu.be\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"soundcloud.com\":\"https:\\/\\/soundcloud.com\\/oembed?url=%url%&format=json&maxwidth=450\",\"slideshare.net\":\"https:\\/\\/www.slideshare.net\\/api\\/oembed\\/2?url=%url%&format=json&maxwidth=450\"}',NULL,NULL,NULL,NULL,NULL),(2,'defaultVisibility','1',NULL,'space',NULL,NULL,NULL,NULL),(3,'defaultJoinPolicy','1',NULL,'space',NULL,NULL,NULL,NULL),(4,'name','HumHub',NULL,NULL,'2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(5,'baseUrl','http://qwertyuiop198.humhub.com',NULL,NULL,'2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(6,'paginationSize','10',NULL,NULL,'2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(7,'displayNameFormat','{profile.firstname} {profile.lastname}',NULL,NULL,'2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(8,'authInternal','1',NULL,'authentication','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(9,'authLdap','0',NULL,'authentication','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(10,'refreshUsers','1',NULL,'authentication_ldap','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(11,'needApproval','0',NULL,'authentication_internal','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(12,'anonymousRegistration','1',NULL,'authentication_internal','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(13,'internalUsersCanInvite','1',NULL,'authentication_internal','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(14,'transportType','php',NULL,'mailing','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(15,'systemEmailAddress','noreply@qwertyuiop198.humhub.com',NULL,'mailing','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(16,'systemEmailName','HumHub',NULL,'mailing','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(17,'receive_email_activities','1',NULL,'mailing','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(18,'receive_email_notifications','2',NULL,'mailing','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(19,'maxFileSize','16777216',NULL,'file','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(20,'maxPreviewImageWidth','200',NULL,'file','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(21,'maxPreviewImageHeight','200',NULL,'file','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(22,'hideImageFileInfo','0',NULL,'file','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(23,'type','CApcCache',NULL,'cache','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(24,'expireTime','3600',NULL,'cache','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(25,'installationId','425a7296249828088c117a88607c9f42',NULL,'admin','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(26,'theme','HumHub',NULL,NULL,'2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(27,'spaceOrder','0',NULL,'space','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(28,'enable','1',NULL,'tour','2015-03-09 15:50:49',0,'2015-03-09 15:50:49',0),(29,'secret','319159ff-9193-4503-8614-3d27cf3f32e1',NULL,NULL,'2015-03-09 15:51:19',0,'2015-03-09 15:51:19',0),(30,'cronLastHourlyRun','1425915611',NULL,NULL,'2015-03-09 16:40:11',0,'2015-03-09 16:40:11',0);
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space`
--

DROP TABLE IF EXISTS `space`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `space` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) DEFAULT NULL,
  `wall_id` int(11) DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  `website` varchar(45) DEFAULT NULL,
  `join_policy` tinyint(4) DEFAULT NULL,
  `visibility` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `tags` text,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_dn` varchar(255) DEFAULT NULL,
  `auto_add_new_members` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space`
--

LOCK TABLES `space` WRITE;
/*!40000 ALTER TABLE `space` DISABLE KEYS */;
INSERT INTO `space` VALUES (1,'e746a555-ff9d-4b59-806f-66ddb891ef8a',2,'Welcome Space','Your first sample space to discover the platform.',NULL,2,2,1,NULL,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1,NULL,1);
/*!40000 ALTER TABLE `space` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space_membership`
--

DROP TABLE IF EXISTS `space_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `space_membership` (
  `space_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `originator_user_id` varchar(45) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `request_message` text,
  `last_visit` datetime DEFAULT NULL,
  `invite_role` tinyint(4) DEFAULT NULL,
  `admin_role` tinyint(4) DEFAULT NULL,
  `share_role` tinyint(4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`space_id`,`user_id`),
  KEY `index_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space_membership`
--

LOCK TABLES `space_membership` WRITE;
/*!40000 ALTER TABLE `space_membership` DISABLE KEYS */;
INSERT INTO `space_membership` VALUES (1,1,NULL,3,NULL,'2015-03-09 15:51:19',1,1,1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `space_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space_module`
--

DROP TABLE IF EXISTS `space_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `space_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` varchar(255) NOT NULL,
  `space_id` int(11) NOT NULL,
  `state` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space_module`
--

LOCK TABLES `space_module` WRITE;
/*!40000 ALTER TABLE `space_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `space_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `space_setting`
--

DROP TABLE IF EXISTS `space_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `space_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `space_id` int(10) DEFAULT NULL,
  `module_id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_space_setting` (`space_id`,`module_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `space_setting`
--

LOCK TABLES `space_setting` WRITE;
/*!40000 ALTER TABLE `space_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `space_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_oembed`
--

DROP TABLE IF EXISTS `url_oembed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_oembed` (
  `url` varchar(255) NOT NULL,
  `preview` text NOT NULL,
  PRIMARY KEY (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_oembed`
--

LOCK TABLES `url_oembed` WRITE;
/*!40000 ALTER TABLE `url_oembed` DISABLE KEYS */;
/*!40000 ALTER TABLE `url_oembed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guid` varchar(45) DEFAULT NULL,
  `wall_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `super_admin` tinyint(4) NOT NULL DEFAULT '0',
  `username` varchar(25) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `auth_mode` varchar(10) NOT NULL,
  `tags` text,
  `language` varchar(5) DEFAULT NULL,
  `last_activity_email` datetime NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  UNIQUE KEY `unique_username` (`username`),
  UNIQUE KEY `unique_guid` (`guid`),
  UNIQUE KEY `unique_wall_id` (`wall_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'5f8c8aa6-3528-445f-b389-de2708f63e89',1,1,1,1,'zakf','zakdoesgaming@gmail.com','local',NULL,'','2015-03-09 15:51:19','2015-03-09 15:51:19',NULL,'2015-03-09 15:51:19',NULL,'2015-03-09 15:51:31');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follow`
--

DROP TABLE IF EXISTS `user_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `send_notifications` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `index_user` (`user_id`),
  KEY `index_object` (`object_model`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follow`
--

LOCK TABLES `user_follow` WRITE;
/*!40000 ALTER TABLE `user_follow` DISABLE KEYS */;
INSERT INTO `user_follow` VALUES (1,'Post',1,1,1);
/*!40000 ALTER TABLE `user_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_http_session`
--

DROP TABLE IF EXISTS `user_http_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_http_session` (
  `id` char(255) NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_http_session`
--

LOCK TABLES `user_http_session` WRITE;
/*!40000 ALTER TABLE `user_http_session` DISABLE KEYS */;
INSERT INTO `user_http_session` VALUES ('gkjahd90a6iedqtj01gi0e5ee4',1425919136,1,'ed051c2635be198bdc56f1030c3d2019__id|s:1:\"1\";ed051c2635be198bdc56f1030c3d2019__name|s:4:\"zakf\";ed051c2635be198bdc56f1030c3d2019title|s:21:\"System Administration\";ed051c2635be198bdc56f1030c3d2019__states|a:1:{s:5:\"title\";b:1;}');
/*!40000 ALTER TABLE `user_http_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_invite`
--

DROP TABLE IF EXISTS `user_invite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_originator_id` int(11) DEFAULT NULL,
  `space_invite_id` int(11) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `source` varchar(45) DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  UNIQUE KEY `unique_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_invite`
--

LOCK TABLES `user_invite` WRITE;
/*!40000 ALTER TABLE `user_invite` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_invite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_mentioning`
--

DROP TABLE IF EXISTS `user_mentioning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_mentioning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_model` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i_user` (`user_id`),
  KEY `i_object` (`object_model`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_mentioning`
--

LOCK TABLES `user_mentioning` WRITE;
/*!40000 ALTER TABLE `user_mentioning` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_mentioning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_module`
--

DROP TABLE IF EXISTS `user_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `state` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_user_module` (`user_id`,`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_module`
--

LOCK TABLES `user_module` WRITE;
/*!40000 ALTER TABLE `user_module` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_password`
--

DROP TABLE IF EXISTS `user_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `algorithm` varchar(20) DEFAULT NULL,
  `password` text,
  `salt` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_password`
--

LOCK TABLES `user_password` WRITE;
/*!40000 ALTER TABLE `user_password` DISABLE KEYS */;
INSERT INTO `user_password` VALUES (1,1,'sha512whirlpool','236b45285711b4b5bc880f0e2dff891a028d05850366a51b11f5cfa32db2364700728047d4313fd7143f134b06414ab7d73c805595b33a6e7621fb30ee670697','650dfca7-7237-45a3-974c-0cf1c36528c8','2015-03-09 15:51:19');
/*!40000 ALTER TABLE `user_password` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_setting`
--

DROP TABLE IF EXISTS `user_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `module_id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_setting` (`user_id`,`module_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_setting`
--

LOCK TABLES `user_setting` WRITE;
/*!40000 ALTER TABLE `user_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wall`
--

DROP TABLE IF EXISTS `wall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `object_model` varchar(50) NOT NULL,
  `object_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wall`
--

LOCK TABLES `wall` WRITE;
/*!40000 ALTER TABLE `wall` DISABLE KEYS */;
INSERT INTO `wall` VALUES (1,'User','User',1,'2015-03-09 15:51:19',NULL,'2015-03-09 15:51:19',NULL),(2,'Space','Space',1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `wall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wall_entry`
--

DROP TABLE IF EXISTS `wall_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wall_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wall_id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wall_entry`
--

LOCK TABLES `wall_entry` WRITE;
/*!40000 ALTER TABLE `wall_entry` DISABLE KEYS */;
INSERT INTO `wall_entry` VALUES (1,2,1,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1),(2,2,2,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1),(3,2,3,'2015-03-09 15:51:19',1,'2015-03-09 15:51:19',1);
/*!40000 ALTER TABLE `wall_entry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-03-09 17:14:58
